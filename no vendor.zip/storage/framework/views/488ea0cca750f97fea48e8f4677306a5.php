<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\SKD\wedangan-drio-last\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>