import "./bootstrap";
import "flowbite";

import Alpine from "alpinejs";
import $ from "jquery";
window.$ = $;
window.Alpine = Alpine;

Alpine.start();
